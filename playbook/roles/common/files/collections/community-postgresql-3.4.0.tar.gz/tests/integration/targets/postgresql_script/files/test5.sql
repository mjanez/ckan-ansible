SELECT * FROM test_array_table WHERE arr_col = %s
