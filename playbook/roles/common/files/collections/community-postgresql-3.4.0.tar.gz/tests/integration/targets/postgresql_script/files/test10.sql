SELECT EXTRACT(epoch from make_interval(secs => 3)) AS extract
